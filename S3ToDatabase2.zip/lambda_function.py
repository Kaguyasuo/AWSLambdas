import json
import pymysql
import boto3
import time

def lambda_handler(event, context):
    # RDS connection details
    print("hello0")
    bucket_name = 'safety-ratings'
    file_key = 'all_safety_ratings.json'
    
    rds_host = 'nhtsa-db.cze20essmpxj.us-east-1.rds.amazonaws.com'
    rds_user = 'admin'
    rds_password = ''
    rds_db_name = 'nhtsa_info'
    
    conn = None
    print("hello1")
    s3 = boto3.client('s3')
    
    json_object = s3.get_object(Bucket=bucket_name, Key=file_key)
    # models_data = json.loads(response['Body'].read().decode('utf-8'))
    
    # response = s3.get_object(Bucket=bucket_name, Key=file_key)
    # models_data = json.loads(response['Body'].read().decode('utf-8'))
    
    # bucket = event['Records']['0']['s3']['bucket']['name']
    # json_file_name = event['Records'][0]['s3']['object']['key']
    # json_object = s3.get_object(Bucket=bucket,Key=json_file_name)
    # print(json_object)
    jsonFileReader = json_object['Body'].read()
    jsonDict = json.loads(jsonFileReader)
    results = []
    try:
        print("hello2")
        conn = pymysql.connect(host=rds_host, user=rds_user, password=rds_password, db=rds_db_name, connect_timeout=60)
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM SafetyRatings")

        cursor.execute("ALTER TABLE SafetyRatings AUTO_INCREMENT = 1")

        time.sleep(2)
        
        for makes in (jsonDict):
            # item.get_object()
            for years in (jsonDict[makes]):
                for resultItems in (jsonDict[makes][years]):
                    print(jsonDict[makes][years][resultItems]['Results'])
                    for resultsArray in (jsonDict[makes][years][resultItems]['Results']):

                        print('\n')
                        vehiclePicture = ""
                        if ('VehiclePicture' in resultsArray):
                            vehiclePicture = resultsArray['VehiclePicture']
                       
                        frontPicture = ""
                        if ('FrontCrashPicture' in resultsArray):
                            frontPicture = resultsArray['FrontCrashPicture']
                            
                        sidePicture = ""
                        if ('SideCrashPicture' in resultsArray):
                            sidePicture = resultsArray['SideCrashPicture']
                            
                        polePicture = ""
                        if ('SidePolePicture' in resultsArray):
                            polePicture = resultsArray['SidePolePicture']

                        
                        frontVideo = ""
                        if ('FrontCrashVideo' in resultsArray):
                            frontVideo = resultsArray['FrontCrashVideo']
                        
                        sideVideo = ""
                        if ('SideCrashVideo' in resultsArray):
                            sideVideo = resultsArray['SideCrashVideo']
                            
                        poleVideo = ""
                        if ('SidePoleVideo' in resultsArray):
                            poleVideo = resultsArray['SidePoleVideo']
                                
                        
                        newDict = (resultsArray['ModelYear'],resultsArray['VehicleId'],resultsArray['OverallRating'],resultsArray['Make'],resultsArray['Model'],\
                        resultsArray['VehicleDescription'],resultsArray['ComplaintsCount'],vehiclePicture, frontPicture,sidePicture,polePicture,frontVideo,sideVideo,poleVideo, resultsArray['OverallFrontCrashRating'],\
                        resultsArray['OverallSideCrashRating'],resultsArray['RolloverRating'], resultsArray['RecallsCount'], resultsArray['InvestigationCount'])
                        pymysql_insert = "INSERT INTO SafetyRatings (Year, Vehicle_ID, OverallRating, Make, Model, VehicleDescription, ComplaintsCount, VehiclePicture, FrontCrashPicture, SideCrashPicture, SidePolePicture, FrontCrashVideo, SideCrashVideo, SidePoleVideo, OverallFrontCrashRating, OverallSideCrashRating, RolloverRating, RecallsCount, InvestigationCount) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                        print(newDict)
                        cursor.execute(pymysql_insert,newDict)
                        conn.commit()
                        # results.append(newDict.values())
                        print(results)
                        
                    print('\n')
            #  results.append(row.values())
        print(results)
        
        
        # connect to RDS database
    
        # conn = pymysql.connect(host=rds_host, user=rds_user, password=rds_password, db=rds_db_name, connect_timeout=5)
        

        cursor.close()
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
    finally:
        if conn:
            conn.close()
    
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Successfully connected to RDS'})
    }

"""
import json
import urllib.parse
import boto3

print('Loading function')

s3 = boto3.client('s3')


def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event and show its content type
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        print("CONTENT TYPE: " + response['ContentType'])
        return response['ContentType']
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
"""


# import json
# import boto3
# import pymysql
# s3_client = boto3.client('s3')
# def lambda_handler(event, context):
#     bucket = event['Records']['0']['s3']['bucket']['name']
#     json_file_name = event['Records'][0]['s3']['object']['key']
#     json_object = s3_client.get_object(Bucket=bucket,Key=json_file_name)
#     jsonFileReader = json_object['Body'].read()
#     jsonDict = json.loads(jsonFileReader)
#     results = []
#     for item in (jsonDict):
#          results.append(row.values())
#     print(results)
#     conn = pymysql.connect(host = 'nhtsa-db.cze20essmpxj.us-east-1.rds.amazonaws.com',user = 'admin',passwd = 'WebWizards101',db = 'nhtsa_info')
#     cursor = conn.cursor()
#     pymysql_insert = cursor.execute("INSERT INTO rchd2(uniquedataid, platformdetails, systemname, processorname, architecturaldetail, nodename) VALUES (%s, %s, %s, %s, %s, %s)"
#     cursor.execute(pymysql_insert,results)
#     conn.commit()
#     cursor.close()
#     conn.close()
#     print(cursor.rowcount, "record inserted successfully into employee table")
#     return {
#         'statusCode' : 200,
#         #'body' json.dumps('hello from lambda!')
       
#     }