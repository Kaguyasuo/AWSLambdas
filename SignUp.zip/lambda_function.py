import json
import pymysql


rds_host = 'nhtsa-db.cze20essmpxj.us-east-1.rds.amazonaws.com'
rds_user = 'admin'
rds_password = 'WebWizards101'
rds_db_name = 'nhtsa_info'
conn = pymysql.connect(host=rds_host, user=rds_user, password=rds_password, db=rds_db_name, connect_timeout=5)

def lambda_handler(event, context):

    # req_body = {"Year" : 2020, "Make": "", "Model": "RDX"}
    
    req_body = event["queryStringParameters"]
    # print(event["body"])
    with conn.cursor() as cur:
        # print("Received Vehicle_IDL {}".format(req_body["Vehicle_ID"]))
        # req_body = {"Username": "Hello", "Password": "World", "UserType": "Customer"}
        sqlBuilder1 = "SELECT * FROM Users where Username='{}'".format(req_body["Username"])
        print(sqlBuilder1)
        cur.execute(sqlBuilder1)
        user = cur.fetchall()
        print(user)
        if (user):
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': 'true',
                    'Content-Type': 'application/json'
                },
                'body': 'failure'
            }
    
        sqlBuilder = "INSERT INTO Users (Username, Password, UserType) VALUES (%s,%s,%s)"
        newDict = (req_body["Username"],req_body["Password"], req_body["UserType"])
        cur.execute(sqlBuilder,newDict)
        conn.commit()
        print(sqlBuilder)
        # cur.execute(sqlBuilder)
        print("Query executed")
        
        
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true',
            'Content-Type': 'application/json'
        },
        'body': 'successful'
    }